# Script for converting source data into collection of CSV files
# for direct DB uplodad (seed.exs):
#
#     mix run priv/repo/get_images.exs source_dir

# This is a formal check that verifies that given directory exists
# and has 'artists' and 'cities' subdirectories:
import_dir = with [dirname] <- System.argv(),
  {:ok, %File.Stat{type: :directory}} <- File.lstat(dirname),
  {:ok, %File.Stat{type: :directory}} <- File.lstat(dirname <> "/artists"),
  {:ok, %File.Stat{type: :directory}} <- File.lstat(dirname <> "/cities")
do
  dirname
else
  _ -> exit("Import dir structure is invalid")
end

artists = :ets.new(:artists, [:set, :public])

# Stuffing Artists and Genres into ETS
Path.wildcard(import_dir <> "/artists/**/*.json")
|> Flow.from_enumerable()
|> Flow.flat_map(fn file ->
  File.read(file)
  |> MonEx.flat_map(&Jason.decode/1)
  |> MonEx.map(& &1["artists"])
  |> MonEx.Result.unwrap([])
end)
|> Flow.map(fn artist ->
  :ets.insert_new(artists, {artist["id"], artist["images"]})
end)
|> Flow.run()

Path.wildcard(import_dir <> "/seed/*.json")
|> Flow.from_enumerable()
|> Flow.flat_map(fn file ->
  File.read(file)
  |> MonEx.flat_map(&Jason.decode/1)
  |> MonEx.map(& &1["artists"]["items"])
  |> MonEx.Result.unwrap([])
end)
|> Flow.map(fn artist ->
  :ets.insert_new(artists, {artist["id"], artist["images"]})
end)
|> Flow.run()

:ets.foldl(fn {id, images}, acc ->
  Enum.map(images, &Map.put(&1, :artist_id, Base62.decode!(id))) ++ acc
end, [], artists)
|> CSV.encode(headers: true)
|> Stream.into(File.stream!("priv/repo/seeds/images.csv"))
|> Stream.run()
